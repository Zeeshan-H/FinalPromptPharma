<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>


    <!-- Fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">

    <!-- Styles -->
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('images/apple-icon.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon.png')); ?>">
    <link href="<?php echo e(asset('css/material-dashboard.css?v=2.1.2')); ?>" rel="stylesheet" />
  
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>




</head>
<body>
    <div id="app">
                <main class="py-4">
                    <?php echo $__env->yieldContent('scripts'); ?>
                    <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH E:\Php-Laravel-Projects\promptpharma\resources\views/admin/app.blade.php ENDPATH**/ ?>