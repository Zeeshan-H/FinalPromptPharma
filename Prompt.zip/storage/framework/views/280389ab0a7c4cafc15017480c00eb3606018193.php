<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PromptPharma</title>
</head>
<body>
    
    <h1><?php echo e($details['title']); ?></h1>

    <img src="https://i.ibb.co/QJ1Z28x/logo-shop.png" alt="Logo" width="400px" height="400px">

    <p><?php echo e($details['body']); ?></p>

    <p>Thank you.</p>
</body>
</html><?php /**PATH E:\Php-Laravel-Projects\promptpharma\resources\views/emails/CheckoutMail.blade.php ENDPATH**/ ?>