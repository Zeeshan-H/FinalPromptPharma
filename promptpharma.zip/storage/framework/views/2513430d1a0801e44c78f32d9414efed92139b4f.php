<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('frontimages/favicon.png')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Linear Icons -->
    <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,300,400,500,600,700,900%7COpen+Sans:300,400,600,700,800" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/bootstrap.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/fontawesome-all.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/animate.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/linear-icons.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/owl.carousel.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/owl.theme.default.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontcss/magnific-popup.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontcss/nouislider.min.css')); ?>">

		<!-- Theme CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/theme.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/theme-elements.css')); ?>">

		<!-- Current Page CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/settings.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/layers.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/navigation.css')); ?>">

		<!-- Skin CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontcss/default.css')); ?>">		
        <script src="<?php echo e(asset('frontjs/style.switcher.localstorage.js')); ?>"></script> 

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('frontcss/custom.css')); ?>">

		<!-- Head Libs -->
        <script src="<?php echo e(asset('frontjs/modernizr.min.js')); ?>"></script>
        


    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">




</head>
<body>
    <div id="app">
                <main class="py-4">
                    <?php echo $__env->yieldContent('scripts'); ?>
                    <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH E:\Github Repositories\PromptPharma\resources\views/prompt/app.blade.php ENDPATH**/ ?>